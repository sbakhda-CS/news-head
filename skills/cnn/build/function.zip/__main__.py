from cortex_client import InputMessage, OutputMessage
import json


def main(params):
    top_head = ['top']
    # Compute and create output
    return OutputMessage.create().with_payload({'route': json.dumps(params.properties), 'top_head': top_head}).to_params()
