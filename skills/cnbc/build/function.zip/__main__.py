from cortex_client import InputMessage, OutputMessage


def main(params):
    top_head = ['top']
    # Compute and create output
    return OutputMessage.create().with_payload({'route': 'cnbc', 'top_head': top_head}).to_params()
